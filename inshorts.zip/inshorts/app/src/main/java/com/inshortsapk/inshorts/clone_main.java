package com.inshortsapk.inshorts;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class clone_main extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_clone_main);
    }
}